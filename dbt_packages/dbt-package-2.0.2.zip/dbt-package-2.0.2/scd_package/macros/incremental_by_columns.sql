{% macro incremental_by_columns(
    src_table=none, 
    incremental_columns=none,
    time_column=none,
    exec_date=none,
    aliases=none,
    column_rename=none,
    exclusion_columns=none,
    add_meta_exec_date=True,
    add_meta_created_at=True,
    handle_duplicates=True,
    filename_column="meta_filename",
    filename_regex="_([0-9]+)$"
) -%}

{% if execute %}
    {% if src_table is none %}
        {% do exceptions.raise_compiler_error('Error: src_table must be defined!') %}
    {% endif %}
    {% if incremental_columns is none %}
        {% do exceptions.raise_compiler_error('Error: incremental_columns must be defined!') %}
    {% endif %}
    {% if time_column is none %}
        {% do exceptions.raise_compiler_error('Error: time_column must be defined!') %}
    {% endif %}
    {% if exec_date is none %}
        {% do exceptions.raise_compiler_error('Error: exec_date must be defined!') %}
    {% endif %}
    {% if handle_duplicates %}
        {% if filename_column is none %}
            {% do exceptions.raise_compiler_error('Error: filename_column must be defined!') %}
        {% endif %}
        {% if filename_regex is none %}
            {% do exceptions.raise_compiler_error('Error: filename_regex must be defined!') %}
        {% endif %}
    {% endif %}
{% endif %}

{% set table_columns = adapter.get_columns_in_relation(src_table) %}

{%- if exclusion_columns is not none -%}
    {%- set exclusion_set = exclusion_columns if exclusion_columns is iterable and exclusion_columns is not string else [exclusion_columns] -%}
    {%- set filtered_columns = [] -%}
    {%- for col in table_columns -%}
        {%- if col.name not in exclusion_set -%}
            {%- do filtered_columns.append(col) -%}
        {%- endif -%}
    {%- endfor -%}
    {%- set table_columns = filtered_columns -%}
{%- endif -%}

CREATE OR REPLACE TEMP VIEW incoming_update AS
SELECT
    {% for col in table_columns %}
        {%- if column_rename is not none and col.name in column_rename -%}
            {{ column_rename.get(col.name) }}
        {% elif aliases is not none and col.name in aliases %}
            {{ col.name }} AS {{aliases.get(col.name)}}
        {%- else -%}
            {{ col.name }}
        {% endif %}, 
    {% endfor %}
    {% if add_meta_exec_date %}
        TIMESTAMP('{{ run_started_at }}') AS meta_exec_date,
    {% endif %}
    {% if add_meta_created_at %}
        CURRENT_TIMESTAMP() AS meta_created_at {% if handle_duplicates %},{% endif %}
    {% endif %}
    {% if handle_duplicates %}
        CAST(REGEXP_REPLACE(REGEXP_EXTRACT({{ filename_column }}, '{{filename_regex}}', 1), '[^0-9]', '') AS BIGINT) AS filename_order_values
    {% endif %}
FROM {{ src_table }}
WHERE {{time_column}} = '{{exec_date}}';

CREATE OR REPLACE TEMP VIEW column_combinations AS
    SELECT DISTINCT
        {% for p in incremental_columns %}
            {% if aliases is not none and p in aliases %}
                {{aliases.get(p)}}
            {%- else -%}
                {{ p }}
            {% endif %}
            {% if not loop.last %},{% endif %}
        {% endfor %}
    FROM incoming_update;

UPDATE {{ this }} AS target
SET meta_is_current = 0
WHERE meta_is_current = 1
AND EXISTS (
    SELECT 1
    FROM column_combinations c
    WHERE
        {% for p in incremental_columns %}
            {% if aliases is not none and p in aliases %}
                target.{{aliases.get(p)}} = c.{{aliases.get(p)}}
            {%- else -%}
                target.{{ p }} = c.{{ p }}
            {% endif %}
            {% if not loop.last %} AND {% endif %}
        {% endfor %}
);

INSERT INTO {{ this }}

{{ scd_macros.incremental_by_columns_insert_incoming_duplicates(incremental_columns, aliases) if handle_duplicates else "
WITH deduplicated_incoming AS (
    SELECT *, 1 AS meta_is_current FROM incoming_update
)" }}

SELECT
    {% for col in table_columns %}
        {% if aliases is not none and col.name in aliases %}
            {{aliases.get(col.name)}}
        {%- else -%}
            {{ col.name }}
        {% endif %}, 
    {% endfor %}
    {% if add_meta_exec_date %}
        meta_exec_date,
    {% endif %}
    {% if add_meta_created_at %}
        meta_created_at,
    {% endif %}
    meta_is_current
FROM deduplicated_incoming;

{% endmacro %}