-- Macro to clean tables. Meant to be used after tests to clean up the tables created.
-- Arguments:
--    - tables: list of exact table paths. ["catalog.schema.table"]
-- Can be run manually:
-- `dbt run-operation cleanup_tables` (Using the `cleanup_tables_default` Variable)
{% macro cleanup_tables(tables, partial_tables, schemas_to_search) %}

{% if not tables %}
    {% set tables = var('cleanup_tables_default', []) %}
{% endif %}

{% if execute %}
    {% for t in tables %}
        {% do log("Dropping table " ~ t, info=True) %}
        {% set query %}
            DROP TABLE IF EXISTS {{ t }};
        {% endset %}
        {% do run_query(query) %}
    {% endfor %}
{% endif %}

{% endmacro %}