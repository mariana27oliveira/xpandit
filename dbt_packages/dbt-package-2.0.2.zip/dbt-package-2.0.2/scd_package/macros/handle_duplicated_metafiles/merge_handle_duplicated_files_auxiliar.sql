{% macro merge_handle_duplicated_files_auxiliar(primary_keys, handle_deletes, aliases=none, open_ended_ts=none, macro_soft_delete=false) %}

MERGE INTO {{ this }} as target
USING (
    SELECT
        {% for pk in primary_keys %}NULL as mergeKey{{ loop.index }}, {% endfor %}
        incoming_update.* EXCEPT(file_ts, prev_hash, next_valid_from, rn_desc),
        0 AS is_delete_event
    FROM incoming_update

    UNION ALL

    SELECT
        {% for pk in primary_keys %}
            {% if aliases is not none %}
                incoming_update.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} AS mergeKey{{ loop.index }},
            {% else %}
                incoming_update.{{ pk }} AS mergeKey{{ loop.index }},
            {% endif %}
        {% endfor %}
        incoming_update.* EXCEPT(file_ts, prev_hash, next_valid_from, rn_desc, rn_first),
        0 AS is_delete_event
    FROM (
        SELECT *,
            ROW_NUMBER() OVER (
                PARTITION BY {% for pk in primary_keys %}{% if aliases is not none %}{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}{% else %}{{ pk }}{% endif %}{% if not loop.last %},{% endif %}{% endfor %}
                ORDER BY meta_valid_from ASC
            ) AS rn_first
        FROM incoming_update
    ) incoming_update
    JOIN {{ this }} AS tgt
        ON {% for pk in primary_keys %}
            {% if aliases is not none %}
                incoming_update.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} = tgt.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}
            {% else %}
                incoming_update.{{ pk }} = tgt.{{ pk }}
            {% endif %}
            {% if not loop.last %} AND {% endif %}
        {% endfor %}
    WHERE tgt.meta_is_current = 1
        {% if open_ended_ts is not none %}
            AND tgt.meta_valid_to = {{ open_ended_ts }}
        {% endif %}
        AND tgt.meta_row_hash <> incoming_update.meta_row_hash
        AND incoming_update.rn_first = 1

    {% if macro_soft_delete %}
        {% if handle_deletes %}

            UNION ALL

            SELECT
                {% for pk in primary_keys %}
                    deleted_keys.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} AS mergeKey{{ loop.index }},
                {% endfor %}
                deleted_keys.*,
                1 AS is_delete_event
            FROM deleted_keys

        {% endif %}
    {% endif %}

) AS source
ON {% for pk in primary_keys %}
    {% if aliases is not none %}
        target.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} = mergeKey{{ loop.index }}
    {% else %}
        target.{{ pk }} = mergeKey{{ loop.index }}
    {% endif %}
    {% if not loop.last %} AND {% endif %}
{% endfor %}

{% endmacro %}