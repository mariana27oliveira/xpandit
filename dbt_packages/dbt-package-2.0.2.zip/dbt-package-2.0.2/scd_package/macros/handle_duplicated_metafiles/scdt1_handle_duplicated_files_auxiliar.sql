{% macro scd1_handle_duplicated_files_auxiliar(primary_keys, handle_duplicated_regex_file_date, handle_duplicated_meta_column) %}

dedup_incoming AS (

WITH base AS (

    SELECT *,
        CAST(regexp_extract({{handle_duplicated_meta_column}}, '{{ handle_duplicated_regex_file_date }}', 1) AS BIGINT) AS file_ts
    FROM incoming_update

),

latest_hash AS (

    SELECT *
    FROM (

        SELECT *,
            ROW_NUMBER() OVER (
                PARTITION BY
                {% for pk in primary_keys %}
                    {{ pk }}{% if not loop.last %},{% endif %}
                {% endfor %}
                ORDER BY file_ts DESC
            ) AS rn_hash

        FROM base

    ) t

    WHERE rn_hash = 1

),

filtered_hash AS (

    SELECT b.*
    FROM base b
    JOIN latest_hash h
      ON
      {% for pk in primary_keys %}
        b.{{ pk }} = h.{{ pk }} AND
      {% endfor %}
        b.meta_row_hash = h.meta_row_hash

)

SELECT *
FROM (

    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY
            {% for pk in primary_keys %}
                {{ pk }}{% if not loop.last %},{% endif %}
            {% endfor %}
            ORDER BY file_ts ASC
        ) AS rn

    FROM filtered_hash

) t

WHERE rn = 1

)

{% endmacro %}