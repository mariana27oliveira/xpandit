-- Ticket: 4121 (Framework - Ingestão Team)
-- This macro serves to allow the insertion of duplicates into the final table when they've come from different source files
-- It will "simulate" running the incremental_by_columns logic for multiple files sequentially by updating the "meta_is_current" column
-- This macro will perform the following:
-- 1. For each "partition" based on the incremental_columns select the maximum "filename_order_values"
-- 2. All records for this maximum will have their "meta_is_current" = 1, while the others will have "meta_is_current" = 0
{% macro incremental_by_columns_insert_incoming_duplicates(incremental_columns, aliases) %}

WITH deduplicated_incoming AS (
    SELECT
        t.*,
        CASE 
            WHEN filename_order_values = MAX(filename_order_values) OVER (
                PARTITION BY 
                    {% for p in incremental_columns %}
                        {% if aliases is not none and p in aliases %}
                            {{ aliases.get(p) }}
                        {% else %}
                            {{ p }}
                        {% endif %}
                        {% if not loop.last %}, {% endif %}
                    {% endfor %}
            ) THEN 1
            ELSE 0
        END AS meta_is_current
    FROM incoming_update t
)

{% endmacro %}