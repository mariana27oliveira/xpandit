{% macro scdt2_handle_duplicated_files_auxiliar(primary_keys, handle_duplicated_regex_file_date, handle_duplicated_meta_column) %}
dedup_incoming AS (
  SELECT * EXCEPT(meta_valid_to),
    CASE
      WHEN next_valid_from IS NOT NULL
        THEN TO_TIMESTAMP(TO_DATE(next_valid_from) - INTERVAL 1 DAY)
      ELSE meta_valid_to
    END AS meta_valid_to
  FROM (
    SELECT *,
      LEAD(meta_valid_from) OVER (
        PARTITION BY {% for pk in primary_keys %}{{ pk }}{% if not loop.last %},{% endif %}{% endfor %}
        ORDER BY file_ts
      ) AS next_valid_from,
      ROW_NUMBER() OVER (
        PARTITION BY {% for pk in primary_keys %}{{ pk }}{% if not loop.last %},{% endif %}{% endfor %}
        ORDER BY file_ts DESC
      ) AS rn_desc
    FROM (
      SELECT *
      FROM (
        SELECT *,
          CAST(regexp_extract({{handle_duplicated_meta_column}}, '{{ handle_duplicated_regex_file_date }}', 1) AS BIGINT) AS file_ts,
          LAG(meta_row_hash) OVER (
            PARTITION BY {% for pk in primary_keys %}{{ pk }}{% if not loop.last %},{% endif %}{% endfor %}
            ORDER BY CAST(regexp_extract({{handle_duplicated_meta_column}}, '{{ handle_duplicated_regex_file_date }}', 1) AS BIGINT)
          ) AS prev_hash
        FROM base_incoming
      ) first_pass
      WHERE prev_hash IS NULL OR prev_hash <> meta_row_hash
    ) deduped
  ) windowed
),
{% endmacro %}


{% macro scdt2_dedup_filter(dedup_table, pk_list, aliases, handle_duplicated_metafiles) %}

{% if handle_duplicated_metafiles %}
    FROM dedup_incoming
    WHERE NOT EXISTS (
        SELECT 1
        FROM {{ this }} AS tgt
        WHERE
            {% for pk in pk_list %}
                {{ dedup_table }}.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} =
                tgt.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}
                {% if not loop.last %} AND {% endif %}
            {% endfor %}
            AND tgt.meta_is_current = 1
            AND tgt.meta_row_hash = {{ dedup_table }}.meta_row_hash
    )

{% else %}
    FROM dedup_incoming

{% endif %}

{% endmacro %}