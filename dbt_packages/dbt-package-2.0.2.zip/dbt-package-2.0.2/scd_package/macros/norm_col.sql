{% macro norm_col(col_expr) -%}
  case
    when {{ col_expr }} is null then '__NULL__'
    else
      lower(trim(cast({{ col_expr }} as string)))
  end
{%- endmacro %}
