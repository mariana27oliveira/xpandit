{% macro scd_type2_default_catchup(
    src_table=none, 
    surrogate_key=none,
    primary_keys=none,
    time_column=none,
    exec_date=none,
    aliases=none,
    column_rename=none,
    exclusion_columns=none,
    add_meta_exec_date=True,
    truncate_meta_date=True,
    handle_duplicated_metafiles = False,
    handle_duplicated_regex_file_date = "(\\\\d{14})$",
    handle_duplicated_meta_column = 'meta_filename'
) -%}

{% if execute %}
    {% if src_table is none %}
        {% do exceptions.raise_compiler_error('Error: src_table must be defined!') %}
    {% endif %}
    {% if primary_keys is none %}
        {% do exceptions.raise_compiler_error('Error: primary_keys must be defined!') %}
    {% endif %}
    {% if time_column is none %}
        {% do exceptions.raise_compiler_error('Error: time_column must be defined!') %}
    {% endif %}
    {% if exec_date is none %}
        {% do exceptions.raise_compiler_error('Error: exec_date must be defined!') %}
    {% endif %}
{% endif %}

{% set pk_list = primary_keys if primary_keys is iterable and primary_keys is not string else [primary_keys] %}

{% set table_columns = adapter.get_columns_in_relation(src_table) %}

{# -- IF SURROGATE_KEY IS REQUIRED
 #}
{% set has_suk = surrogate_key is not none %}

{%- if exclusion_columns is not none -%}
    {%- set exclusion_set = exclusion_columns if exclusion_columns is iterable and exclusion_columns is not string else [exclusion_columns] -%}
    {%- set filtered_columns = [] -%}
    {%- for col in table_columns -%}
        {%- if col.name not in exclusion_set -%}
            {%- do filtered_columns.append(col) -%}
        {%- endif -%}
    {%- endfor -%}
    {%- set table_columns = filtered_columns -%}
{%- endif -%}


WITH base_incoming AS (
    SELECT
        {% for col in table_columns %}
            {%- if column_rename is not none and col.name in column_rename -%}
                {{ column_rename.get(col.name) }}
            {% elif aliases is not none and col.name in aliases %}
                {{ col.name }} AS {{aliases.get(col.name)}}
            {%- else -%}
                {{ col.name }}
            {% endif %}, 
        {% endfor %}
        {% if add_meta_exec_date %}CURRENT_TIMESTAMP()  AS meta_exec_date,{% endif %}

        {% if truncate_meta_date %}
            TO_TIMESTAMP(TO_DATE({{ time_column }})) AS meta_valid_from,
        {% else %}
            TO_TIMESTAMP({{ time_column }}) AS meta_valid_from,
        {% endif %}

        TO_TIMESTAMP('31/12/9999 00:00:00', 'dd/MM/yyyy HH:mm:ss') AS meta_valid_to,
        1 AS meta_is_current
    FROM {{ src_table }}
    WHERE {{time_column}} = '{{exec_date}}'
),

{# 
-- Ticket: 4269 (Board: Framework - Ingestão Team)
-- Auxiliary macro to handle duplicated metafiles: extracts file timestamp from meta_filename using a configurable regex, orders records per primary key based on file timestamp, removes consecutive duplicates with identical meta_row_hash and adjusts meta_valid_to to preserve correct historical intervals
#}
{{ scd_macros.scdt2_handle_duplicated_files_auxiliar(primary_keys, handle_duplicated_regex_file_date, handle_duplicated_meta_column) if handle_duplicated_metafiles else "
dedup_incoming AS (
    SELECT * FROM base_incoming
)," }}

incoming_update AS (
    SELECT
        {# -- CALCULATES SURROGATE_KEY IF REQUIRED
        #}
        {% if has_suk %}
            (
                xxhash64(
                    concat(
                        concat_ws('|',
                            {% for pk in primary_keys %}
                                {% set pk_name = aliases.get(pk) if aliases is not none and pk in aliases else pk %}
                                {{ scd_macros.norm_col(pk_name) }}
                                {%- if not loop.last -%},{%- endif -%}
                            {% endfor %}
                        ),
                        '|',
                        date_format(meta_valid_from, 'yyyy-MM-dd HH:mm:ss')
                    )
                )
                & 9223372036854775807
            ) AS {{ surrogate_key }},
        {% endif %}
        {% if handle_duplicated_metafiles %}
            {#
            -- removes the existing meta_is_current and recalculates it based on rn_desc,
            -- ensuring that only the latest record per primary key (highest file_ts) is marked as current.
            #}
            dedup_incoming.* EXCEPT(meta_is_current),
            CASE WHEN rn_desc = 1 THEN 1 ELSE 0 END AS meta_is_current
        {% else %}
            dedup_incoming.*  
        {% endif %}
    {# 
    -- Prevent reprocessing records that already exist in the target as current with the same hash
    -- Ensure only the latest version per PK is marked as current after deduplication
    #}
    {{ scd_macros.scdt2_dedup_filter(
        'dedup_incoming',
        pk_list,
        aliases,
        handle_duplicated_metafiles
    ) }}
)

{# 
-- Ticket: 4269 (Board: Framework - Ingestão Team)
-- Prepare the source dataset for the merge operation: structures the data to distinguish between updates and inserts and prevents multiple updates when processing duplicated metafiles
#}
{% if handle_duplicated_metafiles %}

    {{ scd_macros.merge_handle_duplicated_files_auxiliar(primary_keys) }}

{% else %}


MERGE INTO {{ this }} as target
USING (

    SELECT 
        {% for pk in primary_keys %}incoming_update.{{ pk }} as mergeKey{{loop.index}},
        {% endfor %}incoming_update.*
    FROM incoming_update
    
    UNION ALL
        
    SELECT  
        {% for pk in primary_keys %}NULL as mergeKey{{loop.index}},
        {% endfor %}incoming_update.*
    FROM incoming_update
    JOIN {{ this }} AS tgt ON 
        {% for pk in primary_keys %}incoming_update.{{ pk }} = tgt.{{ pk }} {% if not loop.last %}AND
        {% endif %}{% endfor %}
    WHERE tgt.meta_is_current = 1 AND tgt.meta_row_hash <> incoming_update.meta_row_hash
    
) 
AS source ON 
    {% for pk in primary_keys %}target.{{ pk }} = mergeKey{{loop.index}} {% if not loop.last %}AND{% endif %} 
    {% endfor %}
{% endif %}

WHEN MATCHED AND target.meta_is_current = 1 AND target.meta_row_hash <> source.meta_row_hash THEN
    UPDATE SET 
        target.meta_is_current = 0,
        {% if truncate_meta_date %}
            target.meta_valid_to = TO_TIMESTAMP(TO_DATE(source.{% if aliases is not none and time_column in aliases %}{{aliases.get(time_column)}}{%- else -%}{{ time_column }}{% endif %}) - INTERVAL 1 DAY)
        {% else %}
            target.meta_valid_to = dateadd(millisecond, -1, TO_TIMESTAMP(source.{% if aliases is not none and time_column in aliases %}{{aliases.get(time_column)}}{%- else -%}{{ time_column }}{% endif %}))
        {% endif %}
        

WHEN NOT MATCHED THEN
    INSERT
        (
            {% if has_suk %}
                {{ surrogate_key }},
            {% endif %}
            {% for col in table_columns %}
                {% if aliases is not none and col.name in aliases %}
                    {{aliases.get(col.name)}}
                {%- else -%}
                    {{ col.name }}
                {% endif %},
            {% endfor %}
            {% if add_meta_exec_date %}meta_exec_date,{% endif %}
            meta_valid_from,
            meta_valid_to,
            meta_is_current
        )
    VALUES
        (
            {% if has_suk %}
                source.{{ surrogate_key }},
            {% endif %}
            {% for col in table_columns %}
                {% if aliases is not none and col.name in aliases %}
                    source.{{aliases.get(col.name)}}
                {%- else -%}
                    source.{{ col.name }}
                {% endif %}, 
            {% endfor %}
            {% if add_meta_exec_date %}source.meta_exec_date,{% endif %}
            source.meta_valid_from,
            source.meta_valid_to,
            source.meta_is_current
        )

{%- endmacro %}