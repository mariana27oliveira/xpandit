{% macro _scd2_pk_in_incoming(pk, aliases) -%}
  {%- if aliases is not none and pk in aliases -%}
    {{ aliases.get(pk) }}
  {%- else -%}
    {{ pk }}
  {%- endif -%}
{%- endmacro %}

{% macro scd_type2_soft_delete_catchup(
    src_table=none,
    surrogate_key=none, 
    primary_keys=none,
    time_column=none,
    exec_date=none,
    aliases=none,
    column_rename=none,
    exclusion_columns=none,
    add_meta_exec_date=True,
    truncate_meta_date=False,
    handle_deletes=True,
    delete_close_strategy="same_day",
    columns_override=none,
    handle_duplicated_metafiles=False,
    handle_duplicated_regex_file_date="(\\\\d{14})$",
    handle_duplicated_meta_column = 'meta_filename'
) -%}

{% if execute %}
    {% if src_table is none %}
        {% do exceptions.raise_compiler_error('Error: src_table must be defined!') %}
    {% endif %}
    {% if primary_keys is none %}
        {% do exceptions.raise_compiler_error('Error: primary_keys must be defined!') %}
    {% endif %}
    {% if time_column is none %}
        {% do exceptions.raise_compiler_error('Error: time_column must be defined!') %}
    {% endif %}
    {% if exec_date is none %}
        {% do exceptions.raise_compiler_error('Error: exec_date must be defined!') %}
    {% endif %}
{% endif %}

{% set pk_list = primary_keys if primary_keys is iterable and primary_keys is not string else [primary_keys] %}
{% if columns_override is not none %}
  {% set table_columns = [] %}
  {% for c in (columns_override if columns_override is iterable and columns_override is not string else [columns_override]) %}
    {% do table_columns.append({'name': c}) %}
  {% endfor %}
{% else %}
  {% set table_columns = adapter.get_columns_in_relation(src_table) %}
{% endif %}

{# -- IF SURROGATE_KEY IS REQUIRED
 #}
{% set has_suk = surrogate_key is not none %}


{%- if exclusion_columns is not none -%}
    {%- set exclusion_set = exclusion_columns if exclusion_columns is iterable and exclusion_columns is not string else [exclusion_columns] -%}
    {%- set filtered_columns = [] -%}
    {%- for col in table_columns -%}
        {%- if col.name not in exclusion_set -%}
            {%- do filtered_columns.append(col) -%}
        {%- endif -%}
    {%- endfor -%}
    {%- set table_columns = filtered_columns -%}
{%- endif -%}


{% set incoming_select_cols -%}
    {%- for col in table_columns -%}
        {%- if column_rename is not none and col.name in column_rename -%}
            {{ column_rename.get(col.name) }}
        {%- elif aliases is not none and col.name in aliases -%}
            {{ col.name }} AS {{ aliases.get(col.name) }}
        {%- else -%}
            {{ col.name }}
        {%- endif -%}
        {%- if not loop.last -%},{%- endif -%}
    {%- endfor -%}
{%- endset %}


{% set target_insert_cols -%}
    {% if has_suk %}
        {{ surrogate_key }},
    {% endif %}
    {%- for col in table_columns -%}
        {%- if aliases is not none and col.name in aliases -%}
            {{ aliases.get(col.name) }}
        {%- else -%}
            {{ col.name }}
        {%- endif -%}
        , 
    {%- endfor -%}
    {%- if add_meta_exec_date -%}meta_exec_date,{%- endif -%}
    meta_valid_from, meta_valid_to, meta_is_current
{%- endset %}

{% set source_values_cols -%}
    {% if has_suk %}
        source.{{ surrogate_key }},
    {% endif %}
    {%- for col in table_columns -%}
        {%- if aliases is not none and col.name in aliases -%}
            source.{{ aliases.get(col.name) }}
        {%- else -%}
            source.{{ col.name }}
        {%- endif -%}
        , 
    {%- endfor -%}
    {%- if add_meta_exec_date -%}source.meta_exec_date,{%- endif -%}
    source.meta_valid_from, source.meta_valid_to, source.meta_is_current
{%- endset %}

{%- set effective_time_col = (aliases.get(time_column) if aliases is not none and time_column in aliases else time_column) -%}
{%- set open_ended_ts = "TO_TIMESTAMP('9999-12-31 00:00:00', 'yyyy-MM-dd HH:mm:ss')" -%}


WITH incoming_keys AS(
    SELECT DISTINCT
        {% for pk in pk_list %}
            {{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} AS {{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}{% if not loop.last %}, {% endif %}
        {% endfor %}
    FROM {{ src_table }}
    WHERE {{ time_column }} = '{{ exec_date }}'
),

deleted_keys AS (
    SELECT
        {% for col in table_columns %}
            s.{{ col.name }},
        {% endfor %}

        {% if add_meta_exec_date %}
            CURRENT_TIMESTAMP() AS meta_exec_date,
        {% endif %}

        TO_TIMESTAMP('{{ exec_date }}') AS meta_valid_from,
        {{ open_ended_ts }} AS meta_valid_to,
        1 AS meta_is_current

    FROM {{ this }} s
    LEFT ANTI JOIN incoming_keys i
        ON
        {% for pk in pk_list %}
            s.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} = i.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}{% if not loop.last %} AND{% endif %}
        {% endfor %}
    WHERE s.meta_is_current = 1
        AND s.meta_valid_to = {{ open_ended_ts }}
),

base_incoming AS (
    SELECT
    {{ incoming_select_cols }},
    {% if add_meta_exec_date %}
        CURRENT_TIMESTAMP() AS meta_exec_date,
    {% endif %}
    {% if truncate_meta_date %}
        TO_TIMESTAMP(TO_DATE({{ effective_time_col }})) AS meta_valid_from,
    {% else %}
        TO_TIMESTAMP({{ effective_time_col }}) AS meta_valid_from,
    {% endif %}
    {{ open_ended_ts }} AS meta_valid_to,
    1 AS meta_is_current
    FROM {{ src_table }}
    WHERE {{ time_column }} = '{{ exec_date }}'
),

{# 
-- Ticket: 4268 (Board: Framework - Ingestão Team)
-- scdt2_handle_duplicated_files_auxiliar auxiliary macro is responsible for deduplicating records within the incoming batch itself (same PK across multiple files), ensuring correct ordering and historical intervals.
-- it does NOT compare incoming data against the existing target table
#}
{{ scd_macros.scdt2_handle_duplicated_files_auxiliar(primary_keys, handle_duplicated_regex_file_date, handle_duplicated_meta_column) if handle_duplicated_metafiles else "
dedup_incoming AS (
    SELECT * FROM base_incoming
)," }}

incoming_update AS (
    SELECT
        {# -- CALCULATES SURROGATE_KEY IF REQUIRED
        #}
        {% if has_suk %}
            (
                xxhash64(
                    concat(
                        concat_ws('|',
                            {% for pk in pk_list %}
                                {% set pk_name = aliases.get(pk) if aliases is not none and pk in aliases else pk %}
                                {{ scd_macros.norm_col(pk_name) }}
                                {%- if not loop.last -%},{%- endif -%}
                            {% endfor %}
                            ), 
                        '|', 
                        date_format(meta_valid_from, 'yyyy-MM-dd HH:mm:ss')
                        )
                    ) 
                & 9223372036854775807
            ) AS {{ surrogate_key }},
        {% endif %}
        {% if handle_duplicated_metafiles %}
            {#
            -- removes the existing meta_is_current and recalculates it based on rn_desc,
            -- ensuring that only the latest record per primary key (highest file_ts) is marked as current.
            #}
            dedup_incoming.* EXCEPT(meta_is_current),
            CASE WHEN rn_desc = 1 THEN 1 ELSE 0 END AS meta_is_current
        {% else %}
            dedup_incoming.*  
        {% endif %}
    {# 
    -- Prevent reprocessing records that already exist in the target as current with the same hash
    -- Ensure only the latest version per PK is marked as current after deduplication
    #}
    {{ scd_macros.scdt2_dedup_filter(
        'dedup_incoming',
        pk_list,
        aliases,
        handle_duplicated_metafiles
    ) }}

)


{# 
-- Ticket: 4268 (Board: Framework - Ingestão Team)
-- Prepare the source dataset for the merge operation: structures the data to distinguish between updates and inserts and prevents multiple updates when processing duplicated metafiles
#}
{% if handle_duplicated_metafiles %}
    {{ scd_macros.merge_handle_duplicated_files_auxiliar(primary_keys=pk_list, handle_deletes=handle_deletes, aliases=aliases, open_ended_ts=open_ended_ts, macro_soft_delete=True) }}
{% else %}
MERGE INTO {{ this }} AS target
USING (
    SELECT
        {% for pk in pk_list %}
            incoming_update.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} AS mergeKey{{ loop.index }}{% if not loop.last %}, {% endif %}
        {% endfor %},
        incoming_update.*,
        0 AS is_delete_event
    FROM incoming_update


    UNION ALL

    SELECT
        {% for pk in pk_list %}
            NULL AS mergeKey{{ loop.index }}{% if not loop.last %}, {% endif %}
        {% endfor %},
        incoming_update.*,
        0 AS is_delete_event
    FROM incoming_update
    JOIN {{ this }} AS tgt
        ON
        {% for pk in pk_list %}
            incoming_update.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} = tgt.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }}{% if not loop.last %} AND{% endif %}
        {% endfor %}
    WHERE tgt.meta_is_current = 1
        AND tgt.meta_row_hash <> incoming_update.meta_row_hash

    {%- if handle_deletes %}

        UNION ALL

        SELECT
            {% for pk in pk_list %}
                deleted_keys.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} AS mergeKey{{ loop.index }},
            {% endfor %}
            deleted_keys.*,
            1 AS is_delete_event
        FROM deleted_keys

    {%- endif -%}
)
AS source
ON
    {% for pk in pk_list %}
        target.{{ scd_macros._scd2_pk_in_incoming(pk, aliases) }} = source.mergeKey{{ loop.index }}{% if not loop.last %} AND{% endif %}
    {% endfor %}
{% endif %}

{# -- SCD2 UPDATE: IF CURRENT TARGET ROW EXISTS FOR THE PK AND meta_row_hash CHANGED
   -- AND CLOSES THE CURRENT ROW (meta_is_current = 0) AND SET meta_valid_to TO JUST BEFORE THE NEW VERSION STARTS.
#}
WHEN MATCHED
    AND target.meta_is_current = 1
    AND target.meta_valid_to = {{ open_ended_ts }}
THEN UPDATE SET
    target.meta_is_current = 
        CASE
            WHEN source.is_delete_event = 1 THEN 1
            WHEN target.meta_row_hash <> source.meta_row_hash THEN 0
            ELSE target.meta_is_current
        END,

    target.meta_valid_to =
        CASE 
            WHEN source.is_delete_event = 1 THEN
                {% if delete_close_strategy == "day_before" %}
                    TO_TIMESTAMP('{{ exec_date }}') - INTERVAL 1 DAY
                {% else %}
                    TO_TIMESTAMP('{{ exec_date }}') - INTERVAL 1 MILLISECOND
                {% endif %}
            WHEN target.meta_row_hash <> source.meta_row_hash THEN
                {% if truncate_meta_date %}
                    TO_TIMESTAMP(DATE_SUB(TO_DATE('{{ exec_date }}'), 1))
                {% else %}
                    (source.meta_valid_from - INTERVAL 1 MILLISECOND)
                {% endif %}
            ELSE target.meta_valid_to
        END
    
    {% if add_meta_exec_date %}
        , target.meta_exec_date =
            CASE 
                WHEN source.is_delete_event = 1 THEN CURRENT_TIMESTAMP()
                ELSE target.meta_exec_date
            END
    {% endif %}

{# -- SCD2 INSERT: INSERT NEW CURRENT VERSION WHEN THERE IS NO MATCHING TARGET ROW FOR THE PK.
#}
WHEN NOT MATCHED AND source.is_delete_event = 0 THEN
    INSERT ({{ target_insert_cols }})
    VALUES ({{ source_values_cols }})
;





{%- endmacro %}
