# How to Run
## Python version 
Make sure the python version on the machine is updated.
Script tested with Python version 3.13.5.
## Import libraries
Before running the script, make sure you have the required dependencies installed.  
If not, install them with:

```
pip install pandas openpyxl
python -m pip install tabulate
```
## Upload Excel file 
Upload the Excel file of the ingestions to this folder.
## Prepare the ingestions list
Put the ingestions in the INGESTIONS_LIST.txt file like this:
```
ingestion1
ingestion2
...
```
Example:
```
sftp-via_verde-brisaom-esg_agua_leituras_brisaom
sftp-hadoop_brisa-b2b_participacoes_total
sftp-hadoop_brisa-clientes_b2b
sftp-hadoop_brisa-b2b_participacoes
...
```
## Run the script
Then, run the command:

```
python main.py <Excel File> <List of ingestions>
```
Example:
```
python main.py EXCEL_FILE.xlsx INGESTIONS_LIST.txt
```

## After the configs are completed can run this script to create QA and PROD version:
```
python config_other_env.py 
```

## Script to transform multiline schema in singleline schema to put in "Schema" column on Excel
Inside the folder **json_schema_multiline_to_singleline** put the multi-line json of the schema in **schema_multiline.json** like this:
```
      {
        "type": "struct",
        "fields": [
          {
            "name": "content",
            "type": {
              "type": "array",
              "elementType": {
                "type": "struct",
                "fields": [
                  { "name": "exitRoadName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "exitTollCode", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "exitTollName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "exitConcessionName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "exitRoadOnNodekm", "type": "long", "nullable": true, "metadata": {} },
                  { "name": "entryRoadName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "entryTollCode", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "entryTollName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "entryConcessionName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "entryRoadOnNodekm", "type": "long", "nullable": true, "metadata": {} },
                  { "name": "classificationName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "value", "type": "double", "nullable": true, "metadata": {} },
                  { "name": "concessionName", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "versionStartDate", "type": "string", "nullable": true, "metadata": {} },
                  { "name": "versionEndDate", "type": "string", "nullable": true, "metadata": {} }
                ]
              },
              "containsNull": true
            },
            "nullable": true,
            "metadata": {}
          }
        ]
      },
```
Then in that folder run on terminal:
```
python main.py 
```
At the end a file named **schema_singleline.json** will be generated with the schema in a single-line like this to put on "Schema" excel column:
```
{"type":"struct","fields":[{"name":"content","type":{"type":"array","elementType":{"type":"struct","fields":[{"name":"exitRoadName","type":"string","nullable":true,"metadata":{}},{"name":"exitTollCode","type":"string","nullable":true,"metadata":{}},{"name":"exitTollName","type":"string","nullable":true,"metadata":{}},{"name":"exitConcessionName","type":"string","nullable":true,"metadata":{}},{"name":"exitRoadOnNodekm","type":"long","nullable":true,"metadata":{}},{"name":"entryRoadName","type":"string","nullable":true,"metadata":{}},{"name":"entryTollCode","type":"string","nullable":true,"metadata":{}},{"name":"entryTollName","type":"string","nullable":true,"metadata":{}},{"name":"entryConcessionName","type":"string","nullable":true,"metadata":{}},{"name":"entryRoadOnNodekm","type":"long","nullable":true,"metadata":{}},{"name":"classificationName","type":"string","nullable":true,"metadata":{}},{"name":"value","type":"double","nullable":true,"metadata":{}},{"name":"concessionName","type":"string","nullable":true,"metadata":{}},{"name":"versionStartDate","type":"string","nullable":true,"metadata":{}},{"name":"versionEndDate","type":"string","nullable":true,"metadata":{}}]},"containsNull":true},"nullable":true,"metadata":{}}]} 
```