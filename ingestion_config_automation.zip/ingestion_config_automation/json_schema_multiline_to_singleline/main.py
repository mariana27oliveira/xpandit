import json

# Path to the JSON file or multiline schema
input_file = "schema_multiline.json"
output_file = "schema_singleline.json"

# Read the content of the file
with open(input_file, "r", encoding="utf-8") as f:
    schema_str = f.read()

try:
    # Convert to dict (ensures it is valid JSON)
    schema_obj = json.loads(schema_str)
except json.JSONDecodeError as e:
    print("Error reading JSON:", e)
    exit(1)

# Convert to single-line JSON
schema_one_line = json.dumps(schema_obj, separators=(",", ":"))

# Save to another file or print to screen
with open(output_file, "w", encoding="utf-8") as f:
    f.write(schema_one_line)

print("Schema converted into single-line JSON:")
print(schema_one_line)