from config_utils import *

import json
import sys
import pandas as pd
import os
#pip install pandas openpyxl


if len(sys.argv) <= 2:
    print("ERROR: Insufficient arguments:")
    print("python main.py <ExcelFile> <IngestionList>")
    exit()

excelFilename = sys.argv[1]
ingestionListDF = pd.read_excel(excelFilename, sheet_name="Ingestions")

ingestionListFilename = sys.argv[2]
ingestionListFile = open(ingestionListFilename,mode='r')
ingestionList = ingestionListFile.read().split("\n")
ingestionListFile.close()

print("\033[94m\nObtained Ingestions:\033[0m")
for item in ingestionList:
    print(item)

# Main folder "Ingestions" in rep root
repo_root = os.path.dirname(os.path.abspath(__file__))
outputFolder = os.path.join(repo_root, "DEV")
os.makedirs(outputFolder, exist_ok=True)

for idx,row in ingestionListDF.iterrows():

    try:
        ingestionName = row["Ingestion Name"]
        
        if ingestionName not in ingestionList:
            continue

        print(f"\033[92m\nStart creating config for the ingestion '{ingestionName}'...\033[0m")

        config = get_base_ingestion_config()
        config["name"] = ingestionName

        add_sources_options(config,row)

        connectionName = get_cell_value(row, "Connection Name")
        config["sources"][0]["data_connection_name"] = connectionName
        if connectionName.startswith("sftp"):
            add_sftp_fields(config,row)
        elif connectionName.startswith("rdbms"):
            add_jdbc_fields(config,row)
        elif connectionName.startswith("api"):
            add_api_fields(config,row)
        else:
            raise Exception("Unidentified Connection Type '"+connectionName+"'")

        add_tags(config,row)
        add_validators(config,row)
        add_transformations(config,row)
        add_query_transformation(config,row)
        add_execution_runtime(config,row,excelFilename)
        add_ingestion_mode(config,row)
        add_targetinfo(config,row)
        add_datasink(config,row)

        # Define subfolders based on ingestion name
        parts = ingestionName.split("-", 2)  
        if len(parts) < 2:
            raise Exception(f"Ingestion name in wrong format to create the path: {ingestionName}")

        ingestion_type = parts[0].upper()
        connection_name = parts[1].upper()

        subfolder = f"{ingestion_type}/{connection_name}"

        # Create final path
        output_path = os.path.join(outputFolder, subfolder)
        os.makedirs(output_path, exist_ok=True)

        # Save JSON 
        with open(os.path.join(output_path, f"{ingestionName}.json"), 'w+') as f:
            json.dump(config, f, indent=4)
            print(f"\033[92m{ingestionName}.json successfully created.\033[0m\n")
    except Exception as e:
        print(f"\033[33mException found at ingestion '{row['Ingestion Name']}'.\nReason: {e}\033[0m")
        print("\033[91mRow will be discarded\033[0m\n")

def get_cell_value(row, column_name):
    column_name_clean = column_name.strip().lower().replace("*", "")
    for col in row.index:
        if col.strip().lower().replace(" *", "") == column_name_clean:
            return row[col]
    raise KeyError(f"Column '{column_name}' (ignoring '*') not found in row")