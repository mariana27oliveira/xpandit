import pandas as pd
import json
from tabulate import tabulate

validatorsList = ["FOOTER","HEADER","FILE_NAME","FILE_NAME_IN_COLUMN","DATE_BETWEEN","HEADER_FILE_UPLOADED"]
instancePool = [
    ["0605-150051-arced152-pool-c5exccs2"], #AEA
    ["0605-150051-piked189-pool-1ckwmi0i"], #AEALO
    ["0605-150052-cut190-pool-ol00w2ia"], #AEBT
    ["0605-150051-award211-pool-z3hnxxv6"], #ATB
    ["0605-150051-lumpy189-pool-h9362iku"], #ATBUS
    ["0605-150051-soft157-pool-ryy3n92q"], #BAE
    ["0605-150052-pit191-pool-l470jbg2"], #BAL
    ["0605-150052-whets190-pool-wqemn3qq"], #BAS
    ["0605-150052-pinky188-pool-tmvxxr5e"], #BCR
    ["0605-150051-tzars188-pool-xzt8lxwy"], #BIO
    ["0605-150052-bawl212-pool-y6c4acaa"], #CTA
    ["0605-150051-roams150-pool-txx5c9ma"] #VVP
]

validatorsMapping = {
    #"Type of validator":"Corresponding Parameter Name"
    "FOOTER":"regex",
    "HEADER":"file_regex",
    "FILE_NAME":"regex",
    "FILE_NAME_IN_COLUMN":"column"
}

transformationsList = ["FILE_NAME_COLUMN"]

transformationsMapping = {
}


# Function to ignore the '*' in the Excel columns
def get_cell_value(row, column_name):
    column_name_clean = column_name.strip().lower().replace("*", "")
    for col in row.index:
        if col.strip().lower().replace(" *", "") == column_name_clean:
            return row[col]
    raise KeyError(f"Column '{column_name}' (ignoring '*') not found in row")


# Ingestion config skeleton
def get_base_ingestion_config():
    return {
        "name":"",
        "sources":[
            {
                "type":"",
                "data_connection_name":"",
                "options":{}
            }
        ],
        "targetInfo": {
          "type": "DATABRICKS",
          "workspace_id": "2418666022521970",
          "catalog": "bae_bronze_dev"
        },
        "execution_runtime": {
          "type": "DATABRICKS_POOL"
        },
        "mode": {
          "type": ""
        },
        "dataSink": {
          "type": "LAKEHOUSE",
          "schema_name": "",
          "curated_table_name": ""
        }
    }


# Config - sources - options - inferSchema
def add_infer_schema(config,row):
    if pd.isna(get_cell_value(row, "Infer Schema")):
      raise Exception("Infer Schema missing")

    config["sources"][0]["options"]["inferSchema"] = bool(get_cell_value(row, "Infer Schema"))
    if not bool(get_cell_value(row, "Infer Schema")):
       config["sources"][0]["schema"] = {}


# SFTP fields
def add_sftp_fields(config,row):

    config["sources"][0]["type"] = "SFTP"
    config["sources"][0]["folder_path"] = get_cell_value(row, "Ingestion Schema Name / File Directory / URL")
    config["sources"][0]["file_name"] = get_cell_value(row, "Ingestion Table / File Name / Endpoint")

    add_copy_type(config, row)
    if get_cell_value(row, "Tipo de cópia") == "FOLDER_SIZE" or get_cell_value(row, "Tipo de cópia") == "HIGHER_THAN_SEQ":
        print("WARNING: Ingestion '"+get_cell_value(row, "Ingestion Name")+"': Copy Type '"+get_cell_value(row, "Tipo de cópia")+"' requires additional fields")

    #Json, Parquet, Xml 
    fileFormat = get_cell_value(row, "File Format")
    if fileFormat == "CSV" or fileFormat == "TXT":
        config["sources"][0]["input_type"] = "DelimitedText"
    elif fileFormat == "Excel" or fileFormat == "Excel 2007 XLSX":
        config["sources"][0]["input_type"] = "Excel"
    elif fileFormat == "Fixed Width":
        config["sources"][0]["input_type"] = "FixedWidth"
    else:
        raise Exception("Error interpreting File Format '"+fileFormat+"'")


    if pd.isna(get_cell_value(row, "Header")):
      raise Exception("Header missing")
    config["sources"][0]["options"]["header"] = bool(get_cell_value(row, "Header"))


    if pd.isna(get_cell_value(row, "Separador")):
        if get_cell_value(row, "Source Type") == "Ficheiro" and get_cell_value(row, "File Format") in ("Excel", "Excel 2007 XLSX"):
            return
        else:
            raise Exception("Delimiter missing")
    config["sources"][0]["options"]["delimiter"] = get_cell_value(row, "Separador")
    if config["sources"][0]["options"]["delimiter"] == "TAB":
      config["sources"][0]["options"]["delimiter"] = "\\t"

    add_infer_schema(config,row)



# JDBC fields
def add_jdbc_fields(config,row):
    config["sources"][0]["type"] = "JDBC"
    config["sources"][0]["table_name"] = f"{get_cell_value(row, "Ingestion Schema Name / File Directory / URL")}.{get_cell_value(row, "Ingestion Table / File Name / Endpoint")}"
    config["sources"][0]["partition_option"] = "None"
    config["sources"][0]["use_query"] = False
    config["sources"][0]["query"] = ""

    if pd.notna(get_cell_value(row, "Incremental Query")):
        config["sources"][0]["use_query"] = True
        config["sources"][0]["query"] = get_cell_value(row, "Incremental Query")

    if pd.notna(get_cell_value(row, "Incremental Check Column")):
        config["sources"][0]["incremental"] = {}
        config["sources"][0]["incremental"]["check_column"] = get_cell_value(row, "Incremental Check Column")


# API fields
def add_api_fields(config,row):
    # Get API type (Always 'API' unless is a specific API type)
    if get_cell_value(row, "Source Type") in ("API", "PAGINATED_API_HTTP_PAGE", "PAGINATED_API_RESPONSE_KEY", "PAGINATED_API_RESPONSE_URL"):
        config["sources"][0]["type"] = "API"
    else:
        config["sources"][0]["type"] = get_cell_value(row, "Source Type")

    # Get the schema if exists
    if pd.notna(get_cell_value(row, "Schema")) and str(get_cell_value(row, "Schema")).strip() != "":
        config["sources"][0]["schema"] = json.loads(get_cell_value(row, "Schema"))
        config["sources"][0]["options"]["inferSchema"] = "false"
    else:
        config["sources"][0]["options"]["inferSchema"] = "true"
        print("\033[33mIngestion without schema on Excel\033[0m")

    # Set pagination configs if it's a paginated API
    if get_cell_value(row, "Source Type") == "PAGINATED_API_HTTP_PAGE":
        config["sources"][0]["pagination"] = {
            "type": "HTTP_PAGE",
            "first_page": 1,
            "json_records_path": f"{get_cell_value(row, "Json Records Path")}"
        }
    elif get_cell_value(row, "Source Type") == "PAGINATED_API_RESPONSE_KEY":
        config["sources"][0]["pagination"] = {
            "type": "RESPONSE_KEY",
            "field": "nextPageKey",
            "next_page_detailed_url": "metrics?nextPageKey={PAGE_KEY}"
        }
    elif get_cell_value(row, "Source Type") == "PAGINATED_API_RESPONSE_URL":
        config["sources"][0]["pagination"] = {
            "type": "RESPONSE_URL",
            "field": "nextPageUrl"
        }

    # Get file format 
    if pd.isna(get_cell_value(row, "File Format")) or str("File Format").strip() == "":
        config["sources"][0]["input_type"] = "Json"
    else:
        config["sources"][0]["input_type"] = get_cell_value(row, "File Format")

    # Set crud_operation
    config["sources"][0]["crud_operation"] = "GET"

    # Get detailed_url
    config["sources"][0]["detailed_url"] = get_cell_value(row, "Ingestion Table / File Name / Endpoint")

    if pd.notna(get_cell_value(row, "Header")):
        config["sources"][0]["options"]["header"] = bool(get_cell_value(row, "Header"))



# Config - sources - options
def add_sources_options(config,row):
    if pd.notna(get_cell_value(row, "Source Options")):
      source_options = get_cell_value(row, "Source Options")
      data = json.loads(F"\u007b{source_options}\u007d")
      config["sources"][0]["options"] = data


def add_tags(config,row):
    tags = {}

    # Company tag
    try:
        if pd.notna(get_cell_value(row, "Company")):
            company_value = str(get_cell_value(row, "Company")).strip().upper()
            if company_value:
                tags["brisa_group"] = company_value
    except KeyError:
        pass

    # Domain tag
    try:
        if pd.notna(get_cell_value(row, "Domain ( schema)")):
            domain_value = str(get_cell_value(row, "Domain ( schema)")).strip().upper()
            if domain_value:
                tags["data_product"] = domain_value
    except KeyError:
        pass

    # Workload tag (as-is)
    try:
        workload_value = get_cell_value(row, "Workload")
        if pd.notna(workload_value):
            workload_value = str(workload_value).strip()
            if workload_value:
                tags["data_product"] = workload_value
    except KeyError:
        pass

    # Always include layer tag
    tags["layer"] = "BRONZE"

    if not tags:
        return  # Nothing to add

    # Insert tags right after 'name'
    reordered_config = {}
    for key, value in config.items():
        reordered_config[key] = value
        if key == "name":
            reordered_config["tags"] = tags

    config.clear()
    config.update(reordered_config)

# Config - sources - validators
def add_validators(config,row):
    try:
      if pd.isna(get_cell_value(row, "Validações")) or str("Validações").strip() == "":
        return
    except KeyError:
       return

    validatorSplit = str(get_cell_value(row, "Validações")).split("\n")
    finalValidatorsList = []
    for validatorStr in validatorSplit:
        validatorTypeAndArg = validatorStr.split("-")
        validatorType = validatorTypeAndArg[0].strip()

        if validatorType not in validatorsList:
           raise Exception("Invalid validator type '"+validatorType+"'")

        if len(validatorTypeAndArg) == 1:
            res = {
                "type": validatorType
            }
        else:
            raw_value = validatorTypeAndArg[1].strip()

            if raw_value.startswith('"') and ":" in raw_value:
                param_json_str = "{\n\"type\": \"" + validatorType + "\",\n" + raw_value + "\n}"
                res = json.loads(param_json_str)
            else:
                escaped_value = raw_value.replace("\\", "\\\\").replace("\"", "\\\"")
                param_json_str = f'{{\n"type": "{validatorType}",\n"{validatorsMapping[validatorType]}": "{escaped_value}"\n}}'
                res = json.loads(param_json_str)

        finalValidatorsList.append(res)

    config["sources"][0]["validators"] = finalValidatorsList


# Config - sources - transformations
def add_transformations(config,row):
    try:
      if pd.isna(get_cell_value(row, "Transformações")) or str("Transformações").strip() == "":
        return
    except KeyError:
       return
      
    transformationSplit = str(get_cell_value(row, "Transformações")).split("\n")
    finalTransformationsList = []
    for transformationStr in transformationSplit:
        transformationTypeAndArg = transformationStr.split("-")
        transformationType = transformationTypeAndArg[0].strip()

        if transformationType not in transformationsList:
           raise Exception("Invalid transformation type '"+transformationType+"'")

        if len(transformationTypeAndArg) == 1:
            res = {
                "type":transformationType
            }
        else:
            raw_value = transformationTypeAndArg[1].strip()

            if raw_value.startswith('"') and ":" in raw_value:
                param_json_str = "{\n\"type\": \"" + transformationType + "\",\n" + raw_value + "\n}"
                res = json.loads(param_json_str)
            else:
                escaped_value = raw_value.replace("\\", "\\\\").replace("\"", "\\\"")
                param_json_str = f'{{\n"type": "{transformationType}",\n"{transformationMapping[transformationType]}": "{escaped_value}"\n}}'
                res = json.loads(param_json_str)

        finalTransformationsList.append(res)

    config["sources"][0]["transformations"] = finalTransformationsList


# Config - query_transformation 
def add_query_transformation(config,row):
    if pd.notna(get_cell_value(row, "Query Transformation")):
        config["query_transformation"] = get_cell_value(row, "Query Transformation")


# Config - sources - copy_type
def add_copy_type(config, row):
    try:
        raw_copy_type = get_cell_value(row, "Tipo de cópia")
        if pd.isna(raw_copy_type) or str(raw_copy_type).strip() == "":
            return
    except KeyError:
        return

    lines = str(raw_copy_type).split("\n")
    result = {}

    for line in lines:
        line = line.strip()
        if not line:
            continue

        parts = line.split(" - ", 1)
        copy_type = parts[0].strip()
        result["type"] = copy_type

        if len(parts) == 2:
            extra = parts[1].strip()

            if extra.startswith('"') and ":" in extra:
                # ex: "query": "SELECT ..."
                extra_json = json.loads("{ " + extra + " }")
                result.update(extra_json)
            else:
                print(f"WARNING: Unrecognized extra copy_type format: {extra}")

    config["sources"][0]["copy_type"] = result


# Config - execution_runtime
def add_execution_runtime(config,row,excelFilename):
    ingestionListDF = pd.read_excel(excelFilename, sheet_name="Connections")
    driver_value = ingestionListDF.loc[
        ingestionListDF["Connection Name"] == get_cell_value(row, "Connection Name"), "Drivers"
    ].values[0]
    if config["sources"][0]["type"] == "JDBC":
        if driver_value == "ojdbc17":
            config["execution_runtime"]["cluster_init_scripts"] = ["/Volumes/operational_dev/volumes/ingestion-frameworks/init_scripts/oracle_driver_17.sh"]
        elif driver_value == "mssql-jdbc-12.10.1.jre8":
            config["execution_runtime"]["cluster_init_scripts"] = ["/Volumes/operational_dev/volumes/ingestion-frameworks/init_scripts/mssql_driver_12.sh"]
        else:
            config["execution_runtime"]["cluster_init_scripts"] = ["/Volumes/operational_dev/volumes/ingestion-frameworks/init_scripts/oracle_driver_17.sh"]
            print("Driver não se encontra na conexão da ingestão então foi colocado o init_script do driver default (Orcale Driver 17)")
   
    catalog_value = get_cell_value(row, "Catalog (bronze)")
    # Set pool_id depending on which Catalog
    if pd.isna(catalog_value) or str(catalog_value).strip() == "":
        config["execution_runtime"]["pool_id"] = instancePool[5][0]
        print("Ingestion "+get_cell_value(row, "Ingestion Name")+" without Catalog, pool set to default (BAE Catalog pool)")
    else: 
        if catalog_value.startswith("aea"):
            config["execution_runtime"]["pool_id"] = instancePool[0][0]
        elif catalog_value.startswith("aealo"):
            config["execution_runtime"]["pool_id"] = instancePool[1][0]
        elif catalog_value.startswith("aebt"):
            config["execution_runtime"]["pool_id"] = instancePool[2][0]
        elif catalog_value.startswith("atb"):
            config["execution_runtime"]["pool_id"] = instancePool[3][0]
        elif catalog_value.startswith("atbus"):
            config["execution_runtime"]["pool_id"] = instancePool[4][0]
        elif catalog_value.startswith("bal"):
            config["execution_runtime"]["pool_id"] = instancePool[6][0]
        elif catalog_value.startswith("bas"):
            config["execution_runtime"]["pool_id"] = instancePool[7][0]
        elif catalog_value.startswith("bcr"):
            config["execution_runtime"]["pool_id"] = instancePool[8][0]
        elif catalog_value.startswith("bio"):
            config["execution_runtime"]["pool_id"] = instancePool[9][0]
        elif catalog_value.startswith("cta"):
            config["execution_runtime"]["pool_id"] = instancePool[10][0]
        elif catalog_value.startswith("vvp"):
            config["execution_runtime"]["pool_id"] = instancePool[11][0]
        elif catalog_value.startswith("bae"):
            config["execution_runtime"]["pool_id"] = instancePool[5][0]
        else:
            config["execution_runtime"]["pool_id"] = instancePool[5][0]
            print("Ingestion "+get_cell_value(row, "Ingestion Name")+" without Catalog, pool set to default (BAE Catalog pool)")
        
        add_execution_runtime_options(config,row)



def add_execution_runtime_options(config,row):
    if pd.notna(get_cell_value(row, "Runtime Options")):
        runtime_options_raw = get_cell_value(row, "Runtime Options")
        runtime_options = json.loads(F"\u007b{runtime_options_raw}\u007d")
        if runtime_options.get('timeout') != None:
            config["execution_runtime"]["timeout"] = runtime_options["timeout"]


# Config - mode
def add_ingestion_mode(config,row):
    mode_raw = get_cell_value(row, "Ingestion Mode")

    parts = str(mode_raw).split(" - ", 1)
    mode_str = parts[0].strip()
    extra_value = parts[1].strip() if len(parts) > 1 else None

    if mode_str == "Full":
        type = "FULL"
        write_operation_mode = "Insert"
    elif mode_str == "Full Overwrite":
            type = "FULL"
            write_operation_mode = "Overwrite"
    elif mode_str == "Incremental":
        type = "INCREMENTAL"
        write_operation_mode = "Insert"
    elif mode_str == "Incremental Upsert":
        type = "INCREMENTAL"
        write_operation_mode = "Upsert"

        if extra_value:
            config["mode"]["last_modified_ts_column"] = extra_value
        else:
            print("WARNING: Ingestion '"+get_cell_value(row, "Ingestion Name")+"': last_modified_ts_column required")
            config["mode"]["last_modified_ts_column"] = "REQUIRED COLUMN FOR INCREMENTAL UPSERT"
    elif mode_str == "Incremental Overwrite":
            type = "INCREMENTAL"
            write_operation_mode = "Overwrite"
    else:
        raise Exception("Ingestion mode not identified")
    
    config["mode"]["type"] = type
    if write_operation_mode != "Insert":
        config["mode"]["write_operation_mode"] = write_operation_mode

    try:
      if pd.notna(get_cell_value(row, "Primary Keys")):
        primarykeysClean = str(get_cell_value(row, "Primary Keys")).replace(" ","")
        config["mode"]["primary_key_columns"] = primarykeysClean.split(",")
      else:
        config["mode"]["generate_row_hash"] = "false"
    except KeyError as e:
        return

    if pd.notna(get_cell_value(row, "Partition")):
        config["mode"]["partition_columns"] = str(get_cell_value(row, "Partition")).split(",")

    if pd.notna(get_cell_value(row, "Partition Column Generator")):
        config["mode"]["partition_columns_generator"] = get_cell_value(row, "Partition Column Generator")
       

# Config - targetInfo
def add_targetinfo(config,row):
    catalog_value = get_cell_value(row, "Catalog (bronze)")
    if pd.notna(catalog_value) and catalog_value != "_bronze_dev":
        catalog = get_cell_value(row, "Catalog (bronze)")
    else:
        catalog = "bae_bronze_dev"
        print("Ingestion "+get_cell_value(row, "Ingestion Name")+" without Catalog, Catalog set to default (BAE Catalog)")

    config["targetInfo"]["workspace_id"] = "2418666022521970"

    config["targetInfo"]["catalog"] = catalog

# Config - dataSink
def add_datasink(config,row):
    config["dataSink"]["type"] = "LAKEHOUSE"
    if pd.notna(get_cell_value(row, "Databricks Database Name")):
        config["dataSink"]["schema_name"] = get_cell_value(row, "Databricks Database Name")
    else:
        config["dataSink"]["schema_name"] = "ungoverned"
        print("Ingestion "+get_cell_value(row, "Ingestion Name")+" without Schema, schema set to default (ungoverned)")

    if pd.isna(get_cell_value(row, "Databricks Table Name")):
        print("No table name found, table name set to default using the last part of the ingestion name. In this case the table name is set to "+get_cell_value(row, "Ingestion Name").replace(get_cell_value(row, "Connection Name"), "").replace("-", ""))
        config["dataSink"]["curated_table_name"] = get_cell_value(row, "Ingestion Name").replace(get_cell_value(row, "Connection Name"), "").replace("-", "")
    else:
        config["dataSink"]["curated_table_name"] = get_cell_value(row, "Databricks Table Name")